# Insurance Policy Graph Model for Neo4j

This README provides instructions for importing the extracted insurance policy data into Neo4j and using it for your insurance recommendation system with RAG (Retrieval Augmented Generation).

## Contents

This package contains the following files:

1. **CSV Files for Neo4j Import**:
   - `nodes_policy.csv` - Insurance policies
   - `nodes_section.csv` - Policy sections
   - `nodes_clause.csv` - Text clauses (primary content for RAG)
   - `nodes_definition.csv` - Defined terms
   - `nodes_exclusion.csv` - Policy exclusions
   - `nodes_coverage.csv` - Policy coverages
   - Relationship CSV files connecting these entities

2. **Neo4j Import Script**:
   - `load_csv_script.cypher` - Cypher script to load all data into Neo4j

3. **Documentation**:
   - `graph_model_validation.md` - Validation report with statistics and sample queries
   - `graph_schema.png` - Visual representation of the graph data model

## Graph Model Overview

The graph model represents D&O insurance policies with the following structure:

- **Policies** are the root nodes, representing each insurance policy document
- **Sections** organize the content of each policy
- **Clauses** contain the actual text content (paragraphs, list items)
- **Definitions**, **Exclusions**, and **Coverages** are specialized entities extracted from relevant sections

This structure allows both structured queries (e.g., "find all exclusions in Chubb policies") and text-based retrieval for RAG applications.

## Import Instructions

### Option 1: Using Neo4j Browser

1. Copy all CSV files to your Neo4j import directory
2. Open Neo4j Browser
3. Paste the contents of `load_csv_script.cypher` into the command input
4. Run the script

### Option 2: Using Neo4j Admin Import Tool

For larger datasets, you may prefer the bulk import tool:

```bash
neo4j-admin import --nodes=Policy=nodes_policy.csv --nodes=Section=nodes_section.csv --nodes=Clause=nodes_clause.csv --nodes=Definition=nodes_definition.csv --nodes=Exclusion=nodes_exclusion.csv --nodes=Coverage=nodes_coverage.csv --relationships=HAS_SECTION=rels_has_section.csv --relationships=CONTAINS_CLAUSE=rels_contains_clause.csv --relationships=CONTAINS_CLAUSE=rels_policy_contains_clause.csv --relationships=DEFINES=rels_defines.csv --relationships=STATES_EXCLUSION=rels_states_exclusion.csv --relationships=PROVIDES_COVERAGE=rels_provides_coverage.csv --relationships=HAS_DEFINITION=rels_has_definition.csv --relationships=HAS_EXCLUSION=rels_has_exclusion.csv --relationships=HAS_COVERAGE=rels_has_coverage.csv
```

## Using the Graph for RAG

For RAG applications, the `Clause` nodes contain the primary text content. You can:

1. Use the full-text search index created in the import script to find relevant clauses
2. Traverse the graph to find related entities (e.g., definitions used in a clause)
3. Use the structured relationships to filter and contextualize results

Example RAG query pattern:

```cypher
// Find clauses related to "directors liability" across policies
CALL db.index.fulltext.queryNodes('clause_text_idx', 'directors liability') YIELD node, score
MATCH (p:Policy)-[:CONTAINS_CLAUSE]->(node)
RETURN p.insurer, p.policyName, node.text, score
ORDER BY score DESC
LIMIT 5
```

## Sample Queries

See `graph_model_validation.md` for additional sample queries to explore the data.
