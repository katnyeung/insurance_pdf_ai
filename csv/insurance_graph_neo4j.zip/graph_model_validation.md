# Graph Model Validation Report

## Summary Statistics

- 6 policy nodes
- 962 section nodes
- 1752 clause nodes
- 49 definition nodes
- 7 exclusion nodes
- 12 coverage nodes

- 962 has_section relationships
- 1752 contains_clause relationships
- 1752 policy_contains_clause relationships
- 49 defines relationships
- 7 states_exclusion relationships
- 12 provides_coverage relationships
- 49 has_definition relationships
- 7 has_exclusion relationships
- 12 has_coverage relationships

## Validation Results

- ✅ All expected files are present
- ✅ Loaded 6 policy nodes
- ✅ Loaded 962 section nodes
- ✅ Loaded 1752 clause nodes
- ✅ Loaded 49 definition nodes
- ✅ Loaded 7 exclusion nodes
- ✅ Loaded 12 coverage nodes
- ✅ Loaded 962 has_section relationships
- ✅ Loaded 1752 contains_clause relationships
- ✅ Loaded 1752 policy_contains_clause relationships
- ✅ Loaded 49 defines relationships
- ✅ Loaded 7 states_exclusion relationships
- ✅ Loaded 12 provides_coverage relationships
- ✅ Loaded 49 has_definition relationships
- ✅ Loaded 7 has_exclusion relationships
- ✅ Loaded 12 has_coverage relationships
- ✅ All has_section relationships reference valid nodes
- ✅ All sections are connected to policies
- ✅ All clauses have text content
- ✅ All policies have associated content (definitions, exclusions, or coverages)
- ✅ Cypher script contains all required commands

## Recommendations for Neo4j Import

1. Copy all CSV files to the Neo4j import directory
2. Run the Cypher script in the Neo4j browser or via the Cypher shell
3. Verify the data was imported correctly by running sample queries

## Sample Queries for Testing

```cypher
// Count nodes by type
MATCH (p:Policy) RETURN count(p) AS PolicyCount;
MATCH (s:Section) RETURN count(s) AS SectionCount;
MATCH (c:Clause) RETURN count(c) AS ClauseCount;
MATCH (d:Definition) RETURN count(d) AS DefinitionCount;
MATCH (e:Exclusion) RETURN count(e) AS ExclusionCount;
MATCH (cov:Coverage) RETURN count(cov) AS CoverageCount;

// Find policies by insurer
MATCH (p:Policy) WHERE p.insurer CONTAINS 'Chubb' RETURN p;

// Find all definitions in a policy
MATCH (p:Policy)-[:HAS_DEFINITION]->(d:Definition) WHERE p.insurer CONTAINS 'Chubb' RETURN d.term, d.definitionText;

// Find all coverages across policies
MATCH (p:Policy)-[:HAS_COVERAGE]->(c:Coverage) RETURN p.insurer, p.policyName, c.coverageName, c.coverageText;

// Find clauses containing specific text (using full-text index)
CALL db.index.fulltext.queryNodes('clause_text_idx', 'liability') YIELD node, score
RETURN node.clauseId, node.text, score ORDER BY score DESC LIMIT 5;
```